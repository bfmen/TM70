source /etc/profile
/home/ShellCrash/start.sh start &