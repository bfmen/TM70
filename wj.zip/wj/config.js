var IS_CPE = ""; // "1"|""
var DEFAULT_LANGUAGE = "zh_cn"; // "zh_cn"|"en_us"
var DEFAULT_LOGIN_LOGO_IMG = ""; // root is index.html
var DEFAULT_TITLE_LOGO_IMG = ""; // root is main.html

var DISPLAY_BATTERY = "block"; // "block"|"none"

var DISPLAY_INTERNET_MENU = "flex"; // "flex"|"none"

var DISPLAY_WIFI_WPS = "block"; // "block"|"none"

var DISPLAY_NETWORK_BASIC = "block"; // "block"|"none"
var DISPLAY_NETWORK_BASIC_MODE = "block"; // "block"|"none"
var DISPLAY_NETWORK_MESSAGE = "block"; // "block"|"none"
var DISPLAY_NETWORK_APN = "block"; // "block"|"none"
var DISPLAY_NETWORK_ESIM = "block"; // "block"|"none"
var DISPLAY_NETWORK_USSD = "block"; // "block"|"none"
var DISPLAY_NETWORK_PING = "block"; // "block"|"none"
var DISPLAY_NETWORK_SIMID = "block"; // "block"|"none"
var DISPLAY_NETWORK_PINLOCK = "block"; // "block"|"none"
var DISPLAY_DATATRAFFIC = "block"; // "block"|"none"

var DISPLAY_WIFI_2G = "block"; // "block"|"none"
var SWITCH_WIFI_2G = 0; // 0:onoff|1:switch
var MAX_CONNECT_WIFI_2G = 32;
var DISPLAY_WIFI_5G = "block"; // "block"|"none"
var SWITCH_WIFI_5G = 0; // 0:onoff|1:switch
var MAX_CONNECT_WIFI_5G = 24;
var HIDE_WIFI_2G = ""; // ""|"none"
var HIDE_WIFI_5G = ""; // ""|"none"
var DISPLAY_WIFI_CHANNEL_2G = "block"; // ""|"none"
var DISPLAY_WIFI_CHANNEL_5G = "block"; // ""|"none"
var DISPLAY_WHITE_LIST = "block"; // "block"|"none"

var DISPLAY_SETTING_TIME = "block"; // "block"|"none"
var DISPLAY_PHONEBOOK = "block"; // "block"|"none"

var DISPLAY_SETTING_FIREWALL = "block"; // "block"|"none"
var DISPLAY_SETTING_PORT = "block"; // "block"|"none"
